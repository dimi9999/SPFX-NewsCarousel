# SETUP INSTRUCTIONS

### 1 Install NodeS
```bash
nvm install 18.17.1
```

### 2 Install dependencies
```bash
npm i
```


